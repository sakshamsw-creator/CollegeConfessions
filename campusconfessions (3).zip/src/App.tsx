import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Home } from './pages/Home';
import { CollegeDetail } from './pages/CollegeDetail';
import { AddReview } from './pages/AddReview';
import { Colleges } from './pages/Colleges';
import { Layout } from './components/Layout';
import { useEffect } from 'react';
import { initFirebase } from './lib/firebase';

export default function App() {
  useEffect(() => {
    initFirebase();
  }, []);

  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/colleges" element={<Colleges />} />
          <Route path="/college/:slug" element={<CollegeDetail />} />
          <Route path="/add" element={<AddReview />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
