import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, Skull, Flame, Laugh, Share2, MoreHorizontal, ArrowBigUp, ArrowBigDown, Zap, User } from 'lucide-react';
import { Review, UserProfile } from '../types';
import { cn } from '../lib/utils';
import { SEED_COLLEGES } from '../seedData';
import { ReviewService, UserService } from '../services/dataService';

interface MemeCardProps {
  review: Review;
  onShare?: () => void;
  compact?: boolean;
}

export const MemeCard: React.FC<MemeCardProps> = ({ review: initialReview, onShare, compact }) => {
  const [review, setReview] = useState(initialReview);
  const [userVote, setUserVote] = useState<'up' | 'down' | null>(null);
  const [lastVoteTime, setLastVoteTime] = useState(0);
  const [authorProfile, setAuthorProfile] = useState<UserProfile | null>(null);
  
  const college = SEED_COLLEGES.find(c => c.id === review.collegeId);
  const isSavage = review.votes > 100 || (review.reactions.skull + review.reactions.fire > 50);

  useEffect(() => {
    // Check local storage for existing vote
    const savedVote = localStorage.getItem(`vote_${review.id}`);
    if (savedVote === 'up' || savedVote === 'down') {
      setUserVote(savedVote as 'up' | 'down');
    }

    // Fetch author profile
    const fetchAuthor = async () => {
      try {
        const p = await UserService.getUserProfile(review.userId);
        setAuthorProfile(p);
      } catch (e) {
        console.error("Failed to fetch author profile:", e);
      }
    };
    fetchAuthor();
  }, [review.id, review.userId]);

  const handleVote = async (type: 'up' | 'down') => {
    const now = Date.now();
    if (now - lastVoteTime < 1000) return; // Basic rate limit

    const newVote = userVote === type ? null : type;
    const oldVote = userVote;

    // Optimistic UI
    let scoreDelta = 0;
    if (oldVote === 'up') scoreDelta -= 1;
    if (oldVote === 'down') scoreDelta += 1;
    if (newVote === 'up') scoreDelta += 1;
    if (newVote === 'down') scoreDelta -= 1;

    setReview(prev => ({ ...prev, votes: prev.votes + scoreDelta }));
    setUserVote(newVote);
    setLastVoteTime(now);

    if (newVote) {
      localStorage.setItem(`vote_${review.id}`, newVote);
    } else {
      localStorage.removeItem(`vote_${review.id}`);
    }

    try {
      await ReviewService.vote(review.id, newVote, oldVote);
    } catch (err) {
      console.error(err);
      // Revert on error
      setReview(prev => ({ ...prev, votes: prev.votes - scoreDelta }));
      setUserVote(oldVote);
    }
  };

  const handleReact = async (type: 'skull' | 'fire' | 'laugh') => {
    setReview(prev => ({
      ...prev,
      reactions: {
        ...prev.reactions,
        [type]: prev.reactions[type] + 1
      }
    }));
    try {
      await ReviewService.react(review.id, type);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl relative",
        compact ? "p-4" : "p-6",
        isSavage && "ring-2 ring-primary/20 shadow-primary/5"
      )}
    >
      {/* Founding Voice Badge */}
      <AnimatePresence>
        {review.isFoundingVoice && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute top-4 left-4 bg-zinc-950 border border-primary/30 text-primary px-3 py-1 rounded-full flex items-center gap-1.5 z-10 shadow-lg shadow-black"
          >
            <Zap className="w-3 h-3 fill-current" />
            <span className="text-[9px] font-black uppercase tracking-tighter italic">Founding Voice Badge</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Savage Badge */}
      <AnimatePresence>
        {isSavage && (
          <motion.div 
            initial={{ x: 100 }}
            animate={{ x: 0 }}
            className="absolute top-4 -right-2 bg-primary text-black px-4 py-1.5 font-black text-[10px] uppercase tracking-tighter rotate-12 z-10 shadow-xl"
          >
            Savage Review 💀
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center border border-primary/20 p-0.5 overflow-hidden">
            {authorProfile?.photoURL ? (
              <img src={authorProfile.photoURL} alt="Avatar" className="w-full h-full rounded-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-full h-full rounded-full bg-zinc-800 flex items-center justify-center">
                 <User className="w-5 h-5 text-zinc-600" />
              </div>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-sm text-white">{authorProfile?.anonymousName || 'Identifying Student...'}</span>
              <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest bg-zinc-800 px-1.5 py-0.5 rounded">Verified Student</span>
            </div>
            <p className="text-[10px] text-zinc-500 font-bold uppercase">{college?.name || 'Unknown University'}</p>
          </div>
        </div>
        <button className="text-zinc-600 hover:text-white transition-colors">
          <MoreHorizontal className="w-5 h-5" />
        </button>
      </div>

      {/* Content */}
      <div className="space-y-4">
        <h3 className={cn(
          "font-black text-white leading-tight font-display transition-colors",
          compact ? "text-lg" : "text-2xl",
          userVote === 'up' && "text-primary/90",
          userVote === 'down' && "text-red-400/90"
        )}>
          “{review.headline}”
        </h3>
        {!compact && (
          <p className="text-zinc-400 text-sm leading-relaxed">
            {review.contentText}
          </p>
        )}
        
        {!compact && (review.expectationVsReality || review.biggestScam) && (
          <div className="grid grid-cols-1 gap-3 pt-2">
            {review.expectationVsReality && (
              <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800/50">
                <span className="text-[9px] font-black uppercase text-zinc-600 tracking-tighter">Expectation vs Reality</span>
                <p className="text-xs text-zinc-300 italic">{review.expectationVsReality}</p>
              </div>
            )}
            {review.biggestScam && (
              <div className="bg-red-950/20 p-3 rounded-xl border border-red-900/20">
                <span className="text-[9px] font-black uppercase text-red-500/60 tracking-tighter">Biggest Scam</span>
                <p className="text-xs text-red-200/80">{review.biggestScam}</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Stats/Tags */}
      {!compact && (
        <div className="flex flex-wrap gap-2 mt-6">
          {review.tags.map(tag => (
            <span key={tag} className="text-[10px] font-bold text-primary bg-primary/5 px-2 py-1 rounded-md border border-primary/10">
              #{tag}
            </span>
          ))}
        </div>
      )}

      {/* Footer Actions */}
      <div className="flex items-center justify-between mt-8 pt-4 border-t border-zinc-800">
        <div className="flex items-center gap-4">
          <div className="flex items-center bg-zinc-950 rounded-2xl border border-zinc-800 p-1">
            <button 
              onClick={() => handleVote('up')}
              className={cn(
                "p-2 rounded-xl transition-all active:scale-125",
                userVote === 'up' ? "bg-primary text-black shadow-lg shadow-primary/20" : "text-zinc-600 hover:text-white"
              )}
            >
              <ArrowBigUp className={cn("w-6 h-6", userVote === 'up' && "fill-current")} />
            </button>
            <span className={cn(
              "px-2 font-black font-mono text-sm min-w-[32px] text-center transition-colors",
              userVote === 'up' ? "text-primary" : userVote === 'down' ? "text-red-500" : "text-zinc-500"
            )}>
              {review.votes}
            </span>
            <button 
              onClick={() => handleVote('down')}
              className={cn(
                "p-2 rounded-xl transition-all active:scale-125",
                userVote === 'down' ? "bg-red-500 text-white shadow-lg shadow-red-500/20" : "text-zinc-600 hover:text-white"
              )}
            >
              <ArrowBigDown className={cn("w-6 h-6", userVote === 'down' && "fill-current")} />
            </button>
          </div>
          
          <div className="flex gap-2">
            <button 
              onClick={() => handleReact('skull')}
              className="group flex items-center gap-1.5 text-xs font-bold bg-zinc-800/50 hover:bg-zinc-800 px-3 py-1.5 rounded-full border border-zinc-700/50 transition-all hover:-translate-y-0.5"
            >
              <span className="group-hover:scale-125 transition-transform">💀</span> 
              <span className="text-zinc-400 group-hover:text-white">{review.reactions.skull}</span>
            </button>
            <button 
              onClick={() => handleReact('fire')}
              className="group flex items-center gap-1.5 text-xs font-bold bg-zinc-800/50 hover:bg-zinc-800 px-3 py-1.5 rounded-full border border-zinc-700/50 transition-all hover:-translate-y-0.5"
            >
              <span className="group-hover:scale-125 transition-transform">🔥</span> 
              <span className="text-zinc-400 group-hover:text-white">{review.reactions.fire}</span>
            </button>
          </div>
        </div>

        <button 
          onClick={onShare}
          className="p-3 bg-zinc-800 hover:bg-primary hover:text-black rounded-2xl transition-all active:scale-90"
        >
          <Share2 className="w-5 h-5" />
        </button>
      </div>
      
      {/* Toast-like feedback */}
      <AnimatePresence>
        {userVote && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="absolute bottom-20 left-6 pointer-events-none"
          >
            <span className="bg-zinc-800 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full border border-zinc-700 text-zinc-400">
               {userVote === 'up' ? "People agree with you 💀" : "Hot take detected 🔥"}
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
