import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, Info } from 'lucide-react';

interface ToastProps {
  message: string;
  isVisible: boolean;
  onClose: () => void;
  type?: 'success' | 'info';
}

export const Toast = ({ message, isVisible, onClose, type = 'success' }: ToastProps) => {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] min-w-[300px]"
        >
          <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-2xl shadow-[0_32px_64px_-16px_rgba(0,0,0,0.5)] flex items-center gap-4 border-l-4 border-l-primary">
            {type === 'success' ? (
              <CheckCircle2 className="w-6 h-6 text-primary" />
            ) : (
              <Info className="w-6 h-6 text-zinc-400" />
            )}
            <div>
              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500 mb-0.5">Notification</div>
              <div className="text-sm font-bold text-white tracking-tight">{message}</div>
            </div>
            <button 
              onClick={onClose}
              className="ml-auto text-zinc-700 hover:text-white transition-colors p-1"
            >
              ✕
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
