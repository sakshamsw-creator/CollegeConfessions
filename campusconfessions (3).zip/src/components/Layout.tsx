import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Plus, User, LogOut } from 'lucide-react';
import { cn } from '../lib/utils';
import { auth, signInWithGoogle } from '../lib/firebase';
import { onAuthStateChanged, signOut, User as FirebaseUser } from 'firebase/auth';
import { UserService } from '../services/dataService';
import { UserProfile } from '../types';

export const Layout = ({ children }: { children: React.ReactNode }) => {
  const [scrolled, setScrolled] = useState(false);
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [showUserMenu, setShowUserMenu] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const p = await UserService.getUserProfile(u.uid);
        setProfile(p);
      } else {
        setProfile(null);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithGoogle();
    } catch (err) {
      console.error("Login failed:", err);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setShowUserMenu(false);
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans">
      <nav className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4 flex items-center justify-between",
        scrolled ? "bg-zinc-950/80 backdrop-blur-md border-b border-zinc-800 py-3" : "bg-transparent"
      )}>
        <Link to="/" className="flex items-center gap-2">
          <div className="bg-primary text-black p-1.5 rounded-lg font-black text-xl italic rotate-3">CC</div>
          <span className="text-xl font-black font-display tracking-tighter">CAMPUS<span className="text-primary italic">CONFESSIONS</span></span>
        </Link>
        <div className="flex items-center gap-4 relative">
          <Link to="/add" className="hidden sm:flex items-center gap-2 bg-zinc-900 border border-zinc-800 px-4 py-2 rounded-full font-bold text-sm hover:border-primary transition-colors">
            <Plus className="w-4 h-4 text-primary" />
            <span>Add Review</span>
          </Link>
          
          {user ? (
            <div className="relative">
              <button 
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-2 pr-2 bg-zinc-900 border border-zinc-800 rounded-full hover:border-zinc-700 transition-colors py-1 px-1"
              >
                {profile?.photoURL ? (
                  <img src={profile.photoURL} className="w-8 h-8 rounded-full border border-zinc-700" alt="Avatar" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center border border-zinc-700">
                    <User className="w-4 h-4 text-zinc-500" />
                  </div>
                )}
                <div className="hidden md:block text-left mr-2">
                  <div className="text-[10px] font-black text-primary uppercase leading-tight tracking-widest">Anonymous</div>
                  <div className="text-[11px] font-bold text-zinc-400 truncate max-w-[100px]">{profile?.anonymousName || 'Identifying...'}</div>
                </div>
              </button>
              
              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl p-2 z-50">
                  <div className="px-3 py-2 border-b border-zinc-800 mb-2">
                    <div className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] mb-1">Your Alias</div>
                    <div className="text-sm font-bold text-white truncate">{profile?.anonymousName}</div>
                  </div>
                  <button 
                    onClick={handleLogout}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-all text-xs font-bold"
                  >
                    <LogOut className="w-4 h-4" /> Sign Out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button 
              onClick={handleLogin}
              className="bg-primary text-black px-6 py-2 rounded-xl font-black text-sm uppercase italic tracking-tighter hover:scale-105 transition-transform"
            >
              Sign In
            </button>
          )}
        </div>
      </nav>

      <main className="flex-grow container mx-auto px-6 pt-24 pb-12">
        {children}
      </main>

      <footer className="border-t border-zinc-900 py-16 px-6">
        <div className="container mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2 space-y-4">
             <div className="text-2xl font-black font-display tracking-tighter">CAMPUS<span className="text-primary italic">CONFESSIONS</span></div>
             <p className="text-zinc-500 text-sm max-w-sm">The only platform where the truth about college life is actually shared. Made for students, by students. No administration, just reality. 💀</p>
          </div>
          <div className="space-y-4">
             <h4 className="text-xs font-black uppercase tracking-widest text-zinc-400">Platform</h4>
             <ul className="space-y-2 text-sm font-bold text-zinc-500">
                <li><Link to="/" className="hover:text-primary transition-colors">Explore Feed</Link></li>
                <li><Link to="/add" className="hover:text-primary transition-colors">Post Confession</Link></li>
                <li><a href="#" className="hover:text-primary transition-colors">Safety Center</a></li>
             </ul>
          </div>
          <div className="space-y-4">
             <h4 className="text-xs font-black uppercase tracking-widest text-zinc-400">Legal</h4>
             <ul className="space-y-2 text-sm font-bold text-zinc-500">
                <li><a href="#" className="hover:text-primary transition-colors">Terms of Chaos</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Moderation Guidelines</a></li>
             </ul>
          </div>
        </div>
        <div className="container mx-auto pt-16 mt-16 border-t border-zinc-900 flex flex-col md:flex-row justify-between items-center gap-4">
           <p className="text-xs font-bold text-zinc-700">© 2026 CAMPUSCONFESSIONS. ALL REALITIES RESERVED.</p>
           <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-600 hover:text-white transition-colors cursor-pointer">X</div>
              <div className="w-8 h-8 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-600 hover:text-white transition-colors cursor-pointer text-xs">IG</div>
           </div>
        </div>
      </footer>
    </div>
  );
};
