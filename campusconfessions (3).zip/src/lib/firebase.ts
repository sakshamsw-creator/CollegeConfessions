import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
// @ts-ignore
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export async function signInWithGoogle() {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    
    // Check if user has a profile, if not create one with a random name
    const userDocRef = doc(db, 'users', user.uid);
    const userDoc = await getDoc(userDocRef);
    
    if (!userDoc.exists()) {
      const adjectives = ['Savage', 'Wild', 'Epic', 'Classic', 'Silent', 'Toxic', 'Based', 'Goated'];
      const nouns = ['Senior', 'Junior', 'Freshie', 'Dropout', 'Scholar', 'Bunker', 'Legend', 'Ghost'];
      const randomName = `${adjectives[Math.floor(Math.random() * adjectives.length)]} ${nouns[Math.floor(Math.random() * nouns.length)]} ${Math.floor(1000 + Math.random() * 9000)}`;
      
      await setDoc(userDocRef, {
        uid: user.uid,
        anonymousName: randomName,
        photoURL: user.photoURL,
        createdAt: serverTimestamp()
      });
    }
    
    return user;
  } catch (error: any) {
    if (error.code === 'auth/popup-closed-by-user') {
      console.warn("User closed the login popup.");
      return null;
    }
    console.error("Google Sign-In Error:", error);
    throw error;
  }
}

export async function initFirebase() {
  try {
    // We don't force anonymous sign-in anymore if we want persistent profiles
    // But we can keep it as a fallback or just let the app handle auth state
    
    // Connection test
    await getDocFromServer(doc(db, 'test', 'connection')).catch(() => {});
    
    return { db, auth };
  } catch (e) {
    console.warn("Firebase initialization error:", e);
    return null;
  }
}
