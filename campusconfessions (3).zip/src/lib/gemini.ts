import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function moderateContent(text: string): Promise<{ safe: boolean; reason?: string }> {
  try {
    const prompt = `Analyze the following college review for:
1. Personal attacks on specific professors or students (Look for names).
2. Hate speech or extreme slurs.
3. Phone numbers or private emails.
4. Illegal activities.

Reply ONLY in JSON format: { "safe": boolean, "reason": "string if risky" }

Review: "${text}"`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const result = JSON.parse(response.text || '{"safe": true}');
    return result;
  } catch (error) {
    console.error("Moderation error:", error);
    // Fail safe: if AI fails, allow but maybe flag for human review
    return { safe: true };
  }
}
