import { useState, useEffect } from 'react';
import { Search, MapPin, Star, MessageSquare, ChevronRight, Filter, SortAsc, LayoutGrid } from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { SEED_COLLEGES } from '../seedData';
import { CollegeService } from '../services/dataService';
import { College } from '../types';
import { cn } from '../lib/utils';

export const Colleges = () => {
  const [colleges, setColleges] = useState<College[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterLocation, setFilterLocation] = useState('All');

  useEffect(() => {
    const fetchColleges = async () => {
      setLoading(true);
      try {
        const liveColleges = await CollegeService.getAllColleges();
        setColleges(liveColleges.length > 0 ? liveColleges : SEED_COLLEGES);
      } catch (err) {
        setColleges(SEED_COLLEGES);
      } finally {
        setLoading(false);
      }
    };
    fetchColleges();
  }, []);

  const locations = ['All', ...Array.from(new Set(colleges.map(c => c.location)))];
  
  const filteredColleges = colleges.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          c.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLocation = filterLocation === 'All' || c.location === filterLocation;
    return matchesSearch && matchesLocation;
  });

  return (
    <div className="space-y-12 pb-20">
      <div className="space-y-4 max-w-2xl">
         <div className="inline-block px-3 py-1 bg-zinc-900 border border-zinc-800 rounded-full text-[10px] font-black uppercase tracking-widest text-zinc-500">
            Database Exploration
         </div>
         <h1 className="text-4xl md:text-6xl font-black font-display uppercase tracking-tight">Browse <span className="text-primary italic">All Colleges</span> 💀</h1>
         <p className="text-zinc-500 font-bold uppercase tracking-widest text-xs">Expose every corner of the educational system. Search and filter through reality.</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center">
         <div className="relative flex-grow w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-600" />
            <input 
              type="text" 
              placeholder="Search by name or city..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl py-4 pl-12 pr-6 text-sm font-bold placeholder:text-zinc-700 focus:border-primary outline-none transition-all"
            />
         </div>
         <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
            {locations.map(loc => (
              <button
                key={loc}
                onClick={() => setFilterLocation(loc)}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest border transition-all whitespace-nowrap",
                  filterLocation === loc 
                    ? "bg-primary text-black border-primary shadow-lg shadow-primary/20" 
                    : "bg-zinc-900 border-zinc-800 text-zinc-500 hover:border-zinc-700"
                )}
              >
                {loc}
              </button>
            ))}
         </div>
      </div>

      {loading ? (
        <div className="py-20 text-center font-black uppercase tracking-[0.3em] text-zinc-800 animate-pulse">Loading University Records...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredColleges.map((college, i) => (
            <motion.div
              key={college.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              className="group relative"
            >
              <Link to={`/college/${college.slug}`}>
                <div className="bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden hover:border-primary/50 transition-all shadow-2xl hover:-translate-y-2">
                   <div className="h-48 relative overflow-hidden">
                      <img 
                        src={college.imageUrl} 
                        alt={college.name} 
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 to-transparent" />
                      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                         <div className="bg-primary text-black px-2 py-1 rounded text-[10px] font-black uppercase italic">
                            {college.reviewCount} Reviews
                         </div>
                         <div className="flex items-center gap-1 bg-black/60 backdrop-blur-md px-2 py-1 rounded-lg border border-white/10">
                            <Star className="w-3 h-3 text-primary fill-current" />
                            <span className="text-xs font-black text-white">{college.overallRating}</span>
                         </div>
                      </div>
                   </div>
                   <div className="p-6 space-y-2">
                      <h3 className="text-xl font-black font-display uppercase italic text-white group-hover:text-primary transition-colors truncate">
                        {college.name}
                      </h3>
                      <div className="flex items-center gap-2 text-zinc-500 font-bold text-xs uppercase tracking-tighter">
                         <MapPin className="w-3 h-3" />
                         {college.location}
                      </div>
                      
                      <div className="pt-4 flex justify-between items-center border-t border-zinc-800 mt-4">
                         <div className="flex -space-x-2">
                            {[1, 2, 3].map(i => (
                               <div key={i} className="w-6 h-6 rounded-full border-2 border-zinc-900 bg-zinc-800 flex items-center justify-center">
                                  <User className="w-3 h-3 text-zinc-600" />
                               </div>
                            ))}
                         </div>
                         <div className="text-[10px] font-black uppercase text-zinc-600 tracking-widest flex items-center gap-1">
                            Explore <ChevronRight className="w-3 h-3" />
                         </div>
                      </div>
                   </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}

      {!loading && filteredColleges.length === 0 && (
         <div className="py-20 text-center space-y-6">
            <div className="w-20 h-20 bg-zinc-900 rounded-3xl border border-dashed border-zinc-800 flex items-center justify-center mx-auto text-3xl">💀</div>
            <div className="space-y-1">
              <h2 className="text-2xl font-black font-display uppercase italic">The Record is Empty</h2>
              <p className="text-zinc-500 font-bold uppercase tracking-widest text-[10px]">Your search didn't match any known institutions.</p>
            </div>
            <Link to="/add" className="inline-block bg-white text-black px-8 py-3 rounded-2xl font-black uppercase text-sm hover:scale-105 transition-transform">
               Add Missing College 🚀
            </Link>
         </div>
      )}
    </div>
  );
};

const User = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
  </svg>
);
