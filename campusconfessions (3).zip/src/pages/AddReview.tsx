import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Sparkles, ChevronRight, ChevronLeft, CheckCircle2, Share2, Download, Instagram, Search, Plus, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { toPng } from 'html-to-image';
import { SEED_COLLEGES } from '../seedData';
import { cn } from '../lib/utils';
import { MemeCard } from '../components/MemeCard';
import { Review, College } from '../types';
import { moderateContent } from '../lib/gemini';
import { ReviewService, CollegeService } from '../services/dataService';

export const AddReview = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [moderationError, setModerationError] = useState<string | null>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  // College Search State
  const [colleges, setColleges] = useState<College[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newCollegeName, setNewCollegeName] = useState('');
  const [newCollegeLocation, setNewCollegeLocation] = useState('');
  const [selectedCollege, setSelectedCollege] = useState<College | null>(null);

  const [formData, setFormData] = useState({
    collegeId: '',
    headline: '',
    content: '',
    ratings: {
      teaching: 5,
      placement: 5,
      life: 5,
      hostel: 5,
      crowd: 5
    },
    expectationVsReality: '',
    biggestScam: '',
    bestThing: '',
    tags: [] as string[]
  });

  useEffect(() => {
    const fetchColleges = async () => {
      try {
        const liveColleges = await CollegeService.getAllColleges();
        setColleges(liveColleges.length > 0 ? liveColleges : SEED_COLLEGES);
      } catch (err) {
        setColleges(SEED_COLLEGES);
      }
    };
    fetchColleges();
  }, []);

  const filteredColleges = searchQuery.length > 0 && !selectedCollege
    ? colleges.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : [];

  const handleSelectCollege = (college: College) => {
    setSelectedCollege(college);
    setFormData({ ...formData, collegeId: college.id });
    setSearchQuery(college.name);
    setIsAddingNew(false);
  };

  const handleCreateNewCollege = async () => {
    console.log("Button clicked: Generate College Page");

    if (newCollegeName.length < 3) {
      console.warn("Validation failed: Name too short");
      setModerationError("College name must be at least 3 characters.");
      return;
    }

    setIsSubmitting(true);
    setModerationError(null);

    try {
      console.log("Starting creation flow for:", newCollegeName);

      // 1. Duplicate check (Parallel to UX)
      const existing = await CollegeService.findByName(newCollegeName);
      if (existing) {
        console.warn("Duplicate found:", existing);
        setModerationError(`"${newCollegeName}" already exists. Use the search to find it.`);
        setIsSubmitting(false);
        return;
      }

      // 2. AI Moderation
      console.log("Triggering AI moderation...");
      const modResult = await moderateContent(`${newCollegeName} ${newCollegeLocation}`);
      if (!modResult.safe) {
        console.warn("AI Flagged content:", modResult.reason);
        setModerationError(modResult.reason || "College name flagged. Please use official names.");
        setIsSubmitting(false);
        return;
      }

      // 3. Database Insert
      console.log("Inserting into database...");
      const created = await CollegeService.createCollege(newCollegeName, newCollegeLocation);
      console.log("Created successfully:", created);

      // 4. Redirect
      console.log("Redirecting to:", `/college/${created.slug}`);
      navigate(`/college/${created.slug}`);
    } catch (err: any) {
      console.error("Unexpected Error in creation flow:", err);
      setModerationError(err.message || "Failed to create college. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleNext = () => setStep(s => s + 1);
  const handlePrev = () => setStep(s => s - 1);

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setModerationError(null);
    try {
      // 1. AI Moderation
      const modResult = await moderateContent(`${formData.headline} ${formData.content}`);
      if (!modResult.safe) {
        setModerationError(modResult.reason || "Content flagged by AI moderation.");
        setIsSubmitting(false);
        return;
      }

      // 2. Save to Firestore
      await ReviewService.createReview({
        collegeId: formData.collegeId,
        headline: formData.headline,
        contentText: formData.content,
        expectationVsReality: formData.expectationVsReality,
        biggestScam: formData.biggestScam,
        bestThing: formData.bestThing,
        rating: 8, // Need to calculate aggregate rating from sub-ratings
        categoryRatings: formData.ratings,
        tags: formData.tags.length ? formData.tags : ['confession', 'reality'],
        upvotes: 0,
        downvotes: 0,
      });

      setShowSuccess(true);
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#facc15', '#f87171', '#ffffff']
      });
    } catch (err) {
      console.error(err);
      setModerationError("Something went wrong while posting. Try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownload = async () => {
    if (cardRef.current === null) return;
    const dataUrl = await toPng(cardRef.current, { cacheBust: true });
    const link = document.createElement('a');
    link.download = `campus-confession-${formData.collegeId}.png`;
    link.href = dataUrl;
    link.click();
  };

  const currentReview: Review = {
    id: 'rev-temp',
    collegeId: formData.collegeId,
    userId: 'anon',
    headline: formData.headline || "Truth about " + (selectedCollege?.name || colleges.find(c => c.id === formData.collegeId)?.name || "Campus"),
    contentText: formData.content || "Wait, you guys are getting good food? 💀",
    expectationVsReality: formData.expectationVsReality,
    biggestScam: formData.biggestScam,
    bestThing: formData.bestThing,
    rating: 8,
    categoryRatings: formData.ratings,
    tags: formData.tags.length ? formData.tags : ['confession', 'reality'],
    votes: 0,
    upvotes: 0,
    downvotes: 0,
    reactions: { skull: 0, fire: 0, laugh: 0 },
    status: 'approved',
    createdAt: new Date().toISOString()
  };

  if (showSuccess) {
    return (
      <div className="max-w-2xl mx-auto py-12 text-center space-y-12">
        <motion.div 
           initial={{ scale: 0.5, opacity: 0 }}
           animate={{ scale: 1, opacity: 1 }}
           className="space-y-4"
        >
          <div className="w-24 h-24 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center mx-auto border-4 border-green-500/10 mb-6">
            <CheckCircle2 className="w-12 h-12" />
          </div>
          <h1 className="text-5xl font-black font-display uppercase tracking-tight">SAVAGE POSTED! 🔥</h1>
          <p className="text-zinc-500 text-lg">Your confession is live. Time to go viral.</p>
        </motion.div>

        <div className="space-y-6">
           <div className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.3em]">Shareable Viral Card</div>
           <div ref={cardRef} className="p-4 bg-zinc-950 rounded-[40px] inline-block shadow-2xl">
              <MemeCard review={currentReview} compact={false} />
           </div>
           
           <div className="flex flex-wrap justify-center gap-4 pt-8">
              <button 
                onClick={handleDownload}
                className="flex items-center gap-2 bg-white text-black px-8 py-4 rounded-2xl font-black text-lg hover:scale-105 transition-transform"
              >
                <Download className="w-5 h-5" /> DOWNLOAD IMAGE
              </button>
              <button className="flex items-center gap-2 bg-[#E1306C] text-white px-8 py-4 rounded-2xl font-black text-lg hover:scale-105 transition-transform">
                <Instagram className="w-5 h-5" /> SHARE TO REELS
              </button>
           </div>
        </div>

        <button 
          onClick={() => navigate('/')}
          className="text-zinc-500 font-bold underline hover:text-white transition-colors pt-12 block mx-auto"
        >
          Back to feed
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-12">
       <div className="flex items-center justify-between mb-12">
         {[1, 2, 3].map(s => (
           <div key={s} className="flex-1 flex items-center">
             <div className={cn(
               "w-10 h-10 rounded-full flex items-center justify-center font-black transition-all",
               step >= s ? "bg-primary text-black" : "bg-zinc-900 text-zinc-700 border border-zinc-800"
             )}>
                {s}
             </div>
             {s < 3 && <div className={cn("flex-grow h-1 mx-2 rounded-full", step > s ? "bg-primary" : "bg-zinc-900")} />}
           </div>
         ))}
       </div>

       <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div 
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="space-y-2">
                <h2 className="text-4xl font-black font-display uppercase italic">The Basics</h2>
                <p className="text-zinc-500">Pick the target and give it a killer title.</p>
              </div>

              <div className="space-y-6 bg-zinc-900/50 p-8 rounded-3xl border border-zinc-800 backdrop-blur-sm">
                {!isAddingNew ? (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em]">Search College</label>
                      <div className="relative">
                        <input 
                          type="text" 
                          value={searchQuery}
                          onChange={e => {
                            setSearchQuery(e.target.value);
                            if (selectedCollege) setSelectedCollege(null);
                          }}
                          placeholder="Type college name (IITB, SRCC...)"
                          className="w-full bg-zinc-950 border border-zinc-800 p-5 pl-14 rounded-2xl text-white font-bold outline-none focus:border-primary ring-offset-zinc-950 focus:ring-2 focus:ring-primary/20 transition-all"
                        />
                        <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-zinc-600" />
                      </div>
                    </div>

                    {searchQuery.length > 0 && !selectedCollege && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden max-h-60 overflow-y-auto shadow-2xl z-20"
                      >
                        {filteredColleges.map(c => (
                          <button 
                            key={c.id} 
                            onClick={() => handleSelectCollege(c)}
                            className="w-full text-left p-4 border-b border-zinc-900 hover:bg-zinc-900 transition-colors flex items-center justify-between group"
                          >
                            <div>
                              <div className="font-bold text-white group-hover:text-primary transition-colors">{c.name}</div>
                              <div className="text-[10px] text-zinc-600 font-bold uppercase tracking-tight">{c.location}</div>
                            </div>
                            <ChevronRight className="w-4 h-4 text-zinc-700 group-hover:text-primary transition-transform group-hover:translate-x-1" />
                          </button>
                        ))}
                        <button 
                          onClick={() => {
                            setIsAddingNew(true);
                            setNewCollegeName(searchQuery);
                          }}
                          className="w-full text-left p-4 bg-primary/5 hover:bg-primary/10 transition-colors flex items-center gap-3 border-t border-zinc-900/50"
                        >
                          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                            <Plus className="w-5 h-5 text-primary" />
                          </div>
                          <div>
                            <div className="font-black text-primary uppercase text-xs">Add "{searchQuery}"</div>
                            <div className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">Be the founder of this college page</div>
                          </div>
                        </button>
                      </motion.div>
                    )}
                  </div>
                ) : (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="space-y-4"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="text-xl font-black text-white italic uppercase flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-primary" /> New Entry
                      </h3>
                      <button onClick={() => setIsAddingNew(false)} className="text-[10px] font-black text-zinc-500 hover:text-white underline uppercase tracking-widest transition-colors">Use Existing</button>
                    </div>
                    <div className="space-y-4 p-6 bg-zinc-950 rounded-[32px] border border-zinc-800/50 shadow-inner">
                      <div className="space-y-2">
                        <label className="text-[9px] font-black uppercase text-zinc-600 tracking-widest">Full Official Name</label>
                        <input 
                          type="text" 
                          value={newCollegeName}
                          onChange={e => setNewCollegeName(e.target.value)}
                          placeholder="e.g. Indian Institute of Technology, Mumbai"
                          className="w-full bg-zinc-900 border border-zinc-800 p-4 rounded-xl text-white font-bold outline-none focus:border-primary transition-colors"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[9px] font-black uppercase text-zinc-600 tracking-widest">Location (City, State)</label>
                        <div className="relative">
                          <input 
                            type="text" 
                            value={newCollegeLocation}
                            onChange={e => setNewCollegeLocation(e.target.value)}
                            placeholder="e.g. Mumbai, Maharashtra"
                            className="w-full bg-zinc-900 border border-zinc-800 p-4 pl-12 rounded-xl text-white font-bold outline-none focus:border-primary transition-colors"
                          />
                          <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-600" />
                        </div>
                      </div>
                      <button 
                        disabled={isSubmitting || newCollegeName.length < 3}
                        onClick={handleCreateNewCollege}
                        className="w-full bg-primary text-black font-black py-4 rounded-xl hover:scale-[1.02] transition-transform active:scale-95 text-xs shadow-lg shadow-primary/20"
                      >
                        {isSubmitting ? "MODERATING..." : "GENERATE COLLEGE PAGE 🚀"}
                      </button>
                    </div>
                  </motion.div>
                )}

                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em]">Savage Headline</label>
                  <input 
                    type="text" 
                    value={formData.headline}
                    onChange={e => setFormData({ ...formData, headline: e.target.value })}
                    placeholder="Short, punchy tagline 💀"
                    className="w-full bg-zinc-950 border border-zinc-800 p-5 rounded-2xl text-white font-bold outline-none focus:border-primary ring-offset-zinc-950 focus:ring-2 focus:ring-primary/20"
                  />
                </div>

                <button 
                  disabled={!formData.collegeId || !formData.headline}
                  onClick={handleNext}
                  className="w-full bg-white text-black font-black py-5 rounded-2xl flex items-center justify-center gap-2 hover:bg-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed group"
                >
                  NEXT <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div 
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="space-y-2">
                <h2 className="text-4xl font-black font-display uppercase italic">Reality Check</h2>
                <p className="text-zinc-500">How bad (or good) is it actually? Be honest.</p>
              </div>

              <div className="grid grid-cols-1 gap-6 bg-zinc-900/50 p-8 rounded-3xl border border-zinc-800">
                {Object.entries(formData.ratings).map(([key, val]) => (
                  <div key={key} className="space-y-3">
                    <div className="flex justify-between items-end">
                      <label className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em]">{key}</label>
                      <span className="text-xl font-black text-primary tabular-nums">{val}/10</span>
                    </div>
                    <input 
                      type="range" min="0" max="10" step="1"
                      value={val}
                      onChange={e => setFormData({ ...formData, ratings: { ...formData.ratings, [key]: parseInt(e.target.value) } })}
                      className="w-full accent-primary h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer" 
                    />
                  </div>
                ))}
                
                <div className="flex gap-4 pt-4">
                  <button onClick={handlePrev} className="flex-1 bg-zinc-800 text-white font-black py-5 rounded-2xl">BACK</button>
                  <button onClick={handleNext} className="flex-[2] bg-white text-black font-black py-5 rounded-2xl hover:bg-primary transition-colors">NEXT</button>
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div 
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <div className="space-y-2">
                <h2 className="text-4xl font-black font-display uppercase italic text-primary">The Tea 🍵</h2>
                <p className="text-zinc-500">The details people actually care about.</p>
              </div>

              <div className="space-y-6 bg-zinc-900/50 p-8 rounded-3xl border border-zinc-800">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em]">The Confession</label>
                  <textarea 
                    value={formData.content}
                    onChange={e => setFormData({ ...formData, content: e.target.value })}
                    rows={4}
                    placeholder="Tell the whole story..."
                    className="w-full bg-zinc-950 border border-zinc-800 p-5 rounded-2xl text-white font-medium outline-none focus:border-primary resize-none"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em]">Biggest Scam</label>
                    <input 
                      type="text" 
                      value={formData.biggestScam}
                      onChange={e => setFormData({ ...formData, biggestScam: e.target.value })}
                      placeholder="e.g. 50% placement claim"
                      className="w-full bg-zinc-950 border border-zinc-800 p-4 rounded-xl text-white outline-none focus:border-primary"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em]">Expectation vs Reality</label>
                    <input 
                      type="text" 
                      value={formData.expectationVsReality}
                      onChange={e => setFormData({ ...formData, expectationVsReality: e.target.value })}
                      placeholder="Short contrast..."
                      className="w-full bg-zinc-950 border border-zinc-800 p-4 rounded-xl text-white outline-none focus:border-primary"
                    />
                  </div>
                </div>

                <div className="p-5 bg-red-500/10 border border-red-500/20 rounded-2xl">
                   {moderationError ? (
                     <p className="text-xs text-red-400 font-black uppercase tracking-widest flex items-center gap-3">
                        <Shield className="w-5 h-5 shrink-0" />
                        {moderationError}
                     </p>
                   ) : (
                     <p className="text-xs text-red-500 font-bold flex items-center gap-3">
                        <Shield className="w-5 h-5 shrink-0" />
                        Our AI scans for personal names of people. Do not post phone numbers or slurs. Stay savage but legal.
                     </p>
                   )}
                </div>

                <div className="flex gap-4">
                  <button onClick={handlePrev} className="flex-1 bg-zinc-800 text-white font-black py-5 rounded-2xl">BACK</button>
                  <button 
                    disabled={isSubmitting || !formData.content}
                    onClick={handleSubmit} 
                    className="flex-[2] bg-primary text-black font-black py-5 rounded-2xl hover:scale-[1.02] transition-transform active:scale-95 flex items-center justify-center gap-3 shadow-xl shadow-primary/20"
                  >
                    {isSubmitting ? "MODERATING..." : <><Sparkles className="w-5 h-5" /> POST CONFESSION</>}
                  </button>
                </div>
              </div>
            </motion.div>
          )}
       </AnimatePresence>
    </div>
  );
};
