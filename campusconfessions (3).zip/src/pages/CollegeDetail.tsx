import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, MapPin, Star, ShieldCheck, AlertTriangle, MessageSquare, Plus, Skull, ChevronRight, Zap, Edit2, Upload, Save, X } from 'lucide-react';
import { motion } from 'motion/react';
import { SEED_COLLEGES, SEED_REVIEWS } from '../seedData';
import { MemeCard } from '../components/MemeCard';
import { cn } from '../lib/utils';
import { ReviewService, CollegeService, PollService } from '../services/dataService';
import { Review, College } from '../types';
import { auth } from '../lib/firebase';
import { Toast } from '../components/Toast';

export const CollegeDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const [college, setCollege] = useState<College | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [poll, setPoll] = useState<any>(null);
  const [hasVoted, setHasVoted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'top' | 'new'>('top');
  const [toast, setToast] = useState<{ show: boolean, msg: string }>({ show: false, msg: '' });
  
  // MOD Mode States
  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setToast({ show: true, msg: "Page link copied! Spread the reality! 💀" });
    setTimeout(() => setToast({ show: false, msg: '' }), 3000);
  };
  const [isEditMode, setIsEditMode] = useState(false);
  const [editName, setEditName] = useState('');
  const [editLocation, setEditLocation] = useState('');
  const [editImageUrl, setEditImageUrl] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const fetchCollegeAndReviews = async () => {
      if (!slug) return;
      setLoading(true);
      try {
        // ... previous fetch logic
        let currentCollege = SEED_COLLEGES.find(c => c.slug === slug) || null;
        if (!currentCollege) {
          currentCollege = await CollegeService.getCollegeBySlug(slug);
        }
        
        if (!currentCollege) {
          setCollege(null);
          setLoading(false);
          return;
        }

        setCollege(currentCollege);
        setEditName(currentCollege.name);
        setEditLocation(currentCollege.location);
        setEditImageUrl(currentCollege.imageUrl);

        // ... poll and review fetching
        const [liveReviews, livePoll] = await Promise.all([
          ReviewService.getReviewsByCollege(currentCollege.id, sortBy),
          PollService.getPollForCollege(currentCollege.id)
        ]);
        
        if (!livePoll) {
          // ... initialization logic
           const newPoll = await PollService.createPoll(
             currentCollege.id, 
             "Would you choose this college again?",
             [
               { id: 'yes', text: 'Yes, Worth it' },
               { id: 'no', text: 'Hard No' }
             ]
           );
           setPoll({ id: newPoll.id, options: [{ id: 'yes', votes: 0 }, { id: 'no', votes: 0 }] });
        } else {
           setPoll(livePoll);
        }

        const seedCollegeReviews = SEED_REVIEWS.filter(r => r.collegeId === currentCollege!.id);
        const allReviews = [...liveReviews];
        if (allReviews.length === 0 && seedCollegeReviews.length > 0) {
          allReviews.push(...seedCollegeReviews);
        }
        setReviews(allReviews);
      } catch (err) {
        console.error("Error loading college profile:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchCollegeAndReviews();
  }, [slug, sortBy]);

  const isCurrentMod = auth.currentUser?.uid === college?.currentModId;

  const handleSaveChanges = async () => {
    if (!college || !isCurrentMod) return;
    setIsSaving(true);
    try {
      await CollegeService.updateCollege(college.id, {
        name: editName,
        location: editLocation,
        imageUrl: editImageUrl
      });
      setCollege({ ...college, name: editName, location: editLocation, imageUrl: editImageUrl });
      setIsEditMode(false);
    } catch (err) {
      console.error("Failed to update college:", err);
      alert("Permission denied or update failed.");
    } finally {
      setIsSaving(false);
    }
  };

  // ... previous helper functions (handlePollVote, calculatePercentage)
  const handlePollVote = async (optionId: string) => {
    if (!poll || hasVoted) return;
    setHasVoted(true);
    const updatedOptions = poll.options.map((opt: any) => 
      opt.id === optionId ? { ...opt, votes: (opt.votes || 0) + 1 } : opt
    );
    setPoll({ ...poll, options: updatedOptions });
    try {
      await PollService.voteInPoll(poll.id, optionId);
    } catch (err) {
      console.error("Poll vote failed:", err);
    }
  };

  const calculatePercentage = (votes: number) => {
    if (!poll) return 0;
    const total = poll.options.reduce((acc: number, opt: any) => acc + (opt.votes || 0), 0);
    if (total === 0) return 0;
    return Math.round((votes / total) * 100);
  };

  if (loading) {
    return (
      <div className="space-y-12 animate-pulse">
        <div className="h-48 bg-zinc-900 rounded-[40px]" />
        <div className="h-24 bg-zinc-900 rounded-[20px]" />
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
           {[1,2,3,4,5].map(i => <div key={i} className="h-32 bg-zinc-900 rounded-3xl" />)}
        </div>
      </div>
    );
  }

  if (!college) {
    return (
      <div className="h-96 flex flex-col items-center justify-center space-y-4">
        <h1 className="text-4xl font-black">College 404 💀</h1>
        <p className="text-zinc-500 font-bold uppercase tracking-widest text-xs">This college hasn't been added to the database yet.</p>
        <Link to="/add" className="bg-primary text-black px-8 py-3 rounded-2xl font-black mt-4 hover:scale-105 transition-transform">
           ADD IT YOURSELF 🚀
        </Link>
        <Link to="/" className="text-zinc-500 font-bold underline hover:text-white transition-colors pt-4">Go back home</Link>
      </div>
    );
  }

  const categories = [
    { label: 'Teaching Quality', score: college.categoryRatings.teaching, color: 'text-blue-400' },
    { label: 'Placement Reality', score: college.categoryRatings.placement, color: 'text-green-400' },
    { label: 'Campus Life', score: college.categoryRatings.life, color: 'text-purple-400' },
    { label: 'Hostel & Food', score: college.categoryRatings.hostel, color: 'text-orange-400' },
    { label: 'Crowd/Vibe', score: college.categoryRatings.crowd, color: 'text-primary' },
  ];

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row gap-8 items-start md:items-end">
        <div className="relative group shrink-0">
          <div className="absolute -inset-1 bg-primary rounded-3xl blur opacity-25"></div>
          <img 
            src={isEditMode ? editImageUrl : college.imageUrl} 
            alt={college.name} 
            className="w-32 h-32 md:w-48 md:h-48 object-cover rounded-3xl relative ring-1 ring-zinc-800"
            referrerPolicy="no-referrer"
          />
          {isEditMode && (
            <div className="absolute inset-0 bg-black/60 rounded-3xl flex items-center justify-center">
              <div className="p-2 bg-zinc-800 rounded-xl cursor-pointer hover:bg-zinc-700 transition-colors">
                <Upload className="w-5 h-5 text-white" />
              </div>
            </div>
          )}
        </div>
        
        <div className="space-y-4 flex-grow">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-1 text-xs font-bold text-zinc-500 hover:text-white transition-colors">
              <ChevronLeft className="w-4 h-4" /> BACK TO ALL COLLEGES
            </Link>
            
            {isCurrentMod && !isEditMode && (
              <button 
                onClick={() => setIsEditMode(true)}
                className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-primary hover:bg-primary/10 px-3 py-1.5 rounded-xl border border-primary/20 transition-all"
              >
                <Edit2 className="w-3 h-3" /> Edit College (MOD)
              </button>
            )}
            
            {isCurrentMod && isEditMode && (
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setIsEditMode(false)}
                  className="p-1.5 text-zinc-500 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <button 
                  onClick={handleSaveChanges}
                  disabled={isSaving}
                  className="bg-primary text-black px-4 py-1.5 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 disabled:opacity-50"
                >
                  {isSaving ? "Saving..." : <><Save className="w-3 h-3" /> Save Changes</>}
                </button>
              </div>
            )}
          </div>

          <div className="space-y-3">
            {isEditMode ? (
              <div className="space-y-3">
                 <input 
                   value={editName}
                   onChange={(e) => setEditName(e.target.value)}
                   className="w-full bg-zinc-900 border border-zinc-800 p-2 rounded-xl text-4xl font-black font-display uppercase tracking-tight text-white focus:border-primary outline-none"
                   placeholder="College Name"
                 />
                 <div className="flex items-center gap-2 text-zinc-500 font-bold">
                    <MapPin className="w-4 h-4" />
                    <input 
                      value={editLocation}
                      onChange={(e) => setEditLocation(e.target.value)}
                      className="bg-zinc-900 border border-zinc-800 p-1.5 rounded-lg text-sm focus:border-primary outline-none text-zinc-300"
                      placeholder="Location"
                    />
                 </div>
                 <div className="flex items-center gap-2 text-zinc-500 font-bold">
                    <Edit2 className="w-4 h-4" />
                    <input 
                      value={editImageUrl}
                      onChange={(e) => setEditImageUrl(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 p-1.5 rounded-lg text-xs focus:border-primary outline-none text-zinc-500"
                      placeholder="Image URL"
                    />
                 </div>
              </div>
            ) : (
              <div className="space-y-1">
                <div className="flex items-center gap-3">
                  <h1 className="text-4xl md:text-6xl font-black font-display uppercase tracking-tight">{college.name}</h1>
                  {isCurrentMod && (
                    <div className="px-2 py-0.5 bg-primary/20 text-primary border border-primary/30 rounded-full text-[8px] font-black uppercase tracking-widest animate-pulse">
                       MOD Active
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-2 text-zinc-500 font-bold">
                   <MapPin className="w-4 h-4" />
                   <span>{college.location}</span>
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-wrap gap-4">
            <div className="bg-zinc-900 border border-zinc-800 px-4 py-2 rounded-2xl flex items-center gap-2">
              <Star className="w-5 h-5 text-primary fill-primary" />
              <span className="text-2xl font-black">{college.overallRating}</span>
              <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest pt-1">/ 10</span>
            </div>
            <div className="bg-zinc-900 border border-zinc-800 px-4 py-2 rounded-2xl flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-zinc-500" />
              <span className="text-2xl font-black">{college.reviewCount}</span>
              <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest pt-1">CONFESSIONS</span>
            </div>
            {!isEditMode && (
              <Link to="/add" className="bg-primary text-black px-6 py-2 rounded-2xl flex items-center gap-2 font-black hover:scale-105 transition-transform">
                <Plus className="w-5 h-5" /> ADD REVIEW
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <section className="relative">
        {college.reviewCount === 0 ? (
          <div className="bg-zinc-900/50 p-12 rounded-[40px] border border-dashed border-zinc-800 text-center space-y-4">
             <div className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.3em]">Rating Accuracy: 0%</div>
             <h2 className="text-3xl font-black font-display uppercase tracking-tight italic text-zinc-700">No data submitted yet 🦗</h2>
             <Link to="/add" className="inline-flex items-center gap-2 text-primary font-black uppercase tracking-widest text-sm hover:underline">
               Be the first to rate this college 💀
             </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories.map((cat, i) => (
              <motion.div 
                key={cat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-zinc-900/50 p-6 rounded-3xl border border-zinc-800/50 space-y-4"
              >
                <div className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em]">{cat.label}</div>
                <div className="flex items-end gap-1">
                    <span className={cn("text-4xl font-black font-display", cat.color)}>{cat.score}</span>
                    <span className="text-xs font-bold text-zinc-700 pb-2">/ 10</span>
                </div>
                <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${cat.score * 10}%` }}
                      transition={{ duration: 1, delay: i * 0.1 + 0.5 }}
                      className={cn("h-full", cat.color.replace('text', 'bg'))}
                    />
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pt-8">
        {/* Realty Check */}
        <div className="lg:col-span-4 space-y-6">
           <div className="p-8 bg-zinc-900/80 border border-zinc-800 rounded-3xl space-y-6">
              <h2 className="text-xl font-black font-display uppercase italic flex items-center gap-2">
                 <ShieldCheck className="w-5 h-5 text-green-500" /> Reality Check
              </h2>
              
              {reviews.length > 0 ? (
                <div className="space-y-4 text-sm font-medium">
                   <div className="flex gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center shrink-0">
                         <Star className="w-3 h-3 text-green-500 fill-green-500" />
                      </div>
                      <p className="text-zinc-300">"Placement cell actually puts in the work for top 20%."</p>
                   </div>
                   <div className="flex gap-3">
                      <div className="w-6 h-6 rounded-full bg-orange-500/20 flex items-center justify-center shrink-0">
                         <AlertTriangle className="w-3 h-3 text-orange-500" />
                      </div>
                      <p className="text-zinc-300">"Hostel rules are strictly medieval. Curfew is 9 PM."</p>
                   </div>
                   <div className="flex gap-3">
                      <div className="w-6 h-6 rounded-full bg-red-500/20 flex items-center justify-center shrink-0">
                         <AlertTriangle className="w-3 h-3 text-red-500" />
                      </div>
                      <p className="text-zinc-300">"Campus Wi-Fi works best at 3 AM. Good luck during exams."</p>
                   </div>
                </div>
              ) : (
                <div className="p-6 bg-zinc-950 rounded-2xl border border-zinc-800 text-center space-y-3">
                   <p className="text-xs text-zinc-500 font-bold leading-relaxed italic">
                      "Waiting for the first confession to generate a Reality Check 🦗"
                   </p>
                </div>
              )}
              <div className="pt-6 border-t border-zinc-800">
                 <div className="text-[10px] font-black text-zinc-600 uppercase mb-2">Re-Choice Poll</div>
                 <div className="text-lg font-bold text-white mb-4">Would you choose this college again?</div>
                 <div className="space-y-3">
                    {poll?.options.map((option: any) => {
                      const percentage = calculatePercentage(option.votes);
                      return (
                        <button 
                          key={option.id}
                          disabled={hasVoted}
                          onClick={() => handlePollVote(option.id)}
                          className={cn(
                            "w-full bg-zinc-950 p-4 rounded-xl border border-zinc-800 flex justify-between items-center group transition-all relative overflow-hidden",
                            hasVoted ? "cursor-default" : "hover:border-primary",
                            option.id === 'yes' && hasVoted && "border-green-500/50",
                            option.id === 'no' && hasVoted && "border-red-500/50"
                          )}
                        >
                          {hasVoted && (
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${percentage}%` }}
                              className={cn(
                                "absolute left-0 top-0 bottom-0 opacity-10",
                                option.id === 'yes' ? "bg-green-500" : "bg-red-500"
                              )}
                            />
                          )}
                          <span className={cn(
                            "font-bold text-zinc-400 group-hover:text-white relative z-10",
                            hasVoted && "text-white"
                          )}>
                            {option.id === 'yes' ? 'Yes, Worth it' : 'Hard No'}
                          </span>
                          {hasVoted && (
                            <span className={cn(
                              "font-black relative z-10",
                              option.id === 'yes' ? "text-green-500" : "text-red-500"
                            )}>
                              {percentage}%
                            </span>
                          )}
                        </button>
                      );
                    })}
                 </div>
              </div>
           </div>
        </div>

        {/* Reviews Feed */}
        <div className="lg:col-span-8 space-y-8">
           <div className="flex items-center justify-between">
            <h2 className="text-2xl font-black font-display uppercase italic">The Confessions</h2>
            <div className="flex gap-2 bg-zinc-950 p-1 rounded-xl border border-zinc-900">
               {[
                 { id: 'top', label: 'Top' },
                 { id: 'new', label: 'New' }
               ].map((tab) => (
                 <button 
                  key={tab.id}
                  onClick={() => setSortBy(tab.id as any)}
                  className={cn(
                    "px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
                    sortBy === tab.id ? "bg-zinc-800 text-primary shadow-lg" : "text-zinc-500 hover:text-zinc-400"
                  )}
                 >
                   {tab.label}
                 </button>
               ))}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-8">
            {reviews.map((review) => (
              <MemeCard key={review.id} review={review} onShare={handleShare} />
            ))}
            
            {!loading && reviews.length === 0 && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-zinc-900/30 border-2 border-dashed border-zinc-800 rounded-[40px] p-12 text-center space-y-8"
              >
                <div className="space-y-4">
                  <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto border border-primary/20">
                     <Skull className="w-10 h-10 text-primary" />
                  </div>
                  <h3 className="text-3xl font-black font-display uppercase tracking-tight">No one has shared the reality yet 👀</h3>
                  <p className="text-zinc-500 max-w-sm mx-auto">Be the <span className="text-primary font-bold">Founding Voice</span> for {college.name} and expose what they don't tell juniors. 💀</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg mx-auto text-left">
                   {[
                     "How are placements actually? 💸",
                     "Campus life vs Expectations? 🏠",
                     "Is the administration a scam? 🤡",
                     "Mess food survivability? 🤢"
                   ].map(prompt => (
                     <div key={prompt} className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl text-xs font-bold text-zinc-400 italic">
                        "{prompt}"
                     </div>
                   ))}
                </div>

                <div className="pt-4">
                  <Link 
                    to="/add" 
                    className="inline-flex items-center gap-3 bg-primary text-black px-10 py-5 rounded-3xl font-black text-xl hover:scale-105 transition-transform shadow-xl shadow-primary/20 group"
                  >
                    BE THE FIRST TO EXPOSE IT 💀
                    <ChevronRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
                
                <div className="flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-widest text-primary/50">
                   <Zap className="w-4 h-4" /> Earn "Founding Voice" Badge
                </div>
              </motion.div>
            )}
            
            {loading && (
              <div className="space-y-6">
                {[1, 2].map(i => (
                  <div key={i} className="h-64 bg-zinc-900/50 rounded-3xl animate-pulse" />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      <Toast 
        isVisible={toast.show}
        message={toast.msg}
        onClose={() => setToast({ show: false, msg: '' })}
      />
    </div>
  );
};
