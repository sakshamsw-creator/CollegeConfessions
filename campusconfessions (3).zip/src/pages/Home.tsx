import { useState, useEffect } from 'react';
import { Search, Flame, TrendingUp, MessageSquare, Skull, Zap, ChevronRight, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';
import { SEED_COLLEGES, SEED_REVIEWS } from '../seedData';
import { MemeCard } from '../components/MemeCard';
import { ReviewService, CollegeService } from '../services/dataService';
import { Review, College } from '../types';
import { Toast } from '../components/Toast';

export const Home = () => {
  const navigate = useNavigate();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [colleges, setColleges] = useState<College[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'top' | 'new' | 'savage'>('top');
  const [toast, setToast] = useState<{ show: boolean, msg: string }>({ show: false, msg: '' });

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [showResults, setShowResults] = useState(false);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setToast({ show: true, msg: "Link copied to clipboard! Share the chaos! 💀" });
    setTimeout(() => setToast({ show: false, msg: '' }), 3000);
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [liveReviews, liveColleges] = await Promise.all([
          ReviewService.getAllReviews(sortBy),
          CollegeService.getAllColleges()
        ]);
        
        setReviews(liveReviews.length > 0 ? liveReviews : SEED_REVIEWS);
        setColleges(liveColleges.length > 0 ? liveColleges : SEED_COLLEGES);
      } catch (err) {
        console.error(err);
        setReviews(SEED_REVIEWS);
        setColleges(SEED_COLLEGES);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [sortBy]);

  const filteredColleges = searchQuery.length > 0
    ? colleges.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : [];

  return (
    <div className="space-y-16">
      {/* Hero */}
      <section className="text-center space-y-8 pt-12 pb-20 relative px-4">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-radial-gradient from-primary/10 to-transparent blur-3xl -z-10 opacity-30"></div>
        
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           className="inline-block px-4 py-1.5 bg-zinc-900 border border-zinc-800 rounded-full text-xs font-black uppercase tracking-widest text-primary mb-4"
        >
           The Truth starts here 🔥
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-6xl md:text-9xl font-black font-display tracking-tight text-white leading-[0.85]"
        >
          See what they <br />
          <span className="text-primary italic">DON'T</span> put in <br />
          the brochure 💀
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-zinc-400 text-lg md:text-2xl max-w-3xl mx-auto font-medium"
        >
          Brutally honest, anonymous college reviews. No filters, no faculty oversight, just pure reality.
        </motion.p>
        
        <div className="max-w-2xl mx-auto relative pt-12">
          <div className="relative group">
            <div className="absolute -inset-2 bg-gradient-to-r from-primary via-accent to-primary rounded-3xl blur opacity-20 group-hover:opacity-40 transition duration-1000 group-hover:duration-200 animate-pulse"></div>
            <div className="relative flex items-center bg-zinc-900 rounded-2xl px-6 py-5 ring-1 ring-zinc-800 shadow-2xl">
              <Search className="w-8 h-8 text-zinc-500 mr-4" />
              <input 
                type="text" 
                value={searchQuery}
                onChange={e => {
                  setSearchQuery(e.target.value);
                  setShowResults(true);
                }}
                onFocus={() => setShowResults(true)}
                placeholder="Search your college (IITB, VIT, DU...)"
                className="bg-transparent border-none outline-none w-full text-xl md:text-2xl font-bold placeholder:text-zinc-700 focus:ring-0 text-white"
              />
            </div>

            {/* Search Results */}
            <AnimatePresence>
              {showResults && searchQuery.length > 0 && (
                <>
                  <div 
                    className="fixed inset-0 z-10" 
                    onClick={() => setShowResults(false)}
                  />
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full left-0 right-0 mt-4 bg-zinc-900/90 border border-zinc-800 rounded-3xl overflow-hidden shadow-[0_32px_64px_-16px_rgba(0,0,0,0.5)] backdrop-blur-xl z-20 text-left"
                  >
                    <div className="max-h-[400px] overflow-y-auto">
                      {filteredColleges.length > 0 ? (
                        filteredColleges.map(c => (
                          <button 
                            key={c.id} 
                            onClick={() => navigate(`/college/${c.slug}`)}
                            className="w-full p-5 border-b border-zinc-800/50 hover:bg-white/5 transition-colors flex items-center justify-between group"
                          >
                            <div>
                              <div className="font-black text-white group-hover:text-primary transition-colors text-lg uppercase italic">{c.name}</div>
                              <div className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">{c.location}</div>
                            </div>
                            <ChevronRight className="w-5 h-5 text-zinc-700 group-hover:text-primary group-hover:translate-x-1 transition-all" />
                          </button>
                        ))
                      ) : (
                        <div className="p-8 text-center space-y-4">
                           <div className="w-16 h-16 bg-zinc-800 rounded-2xl flex items-center justify-center mx-auto">
                             <Skull className="w-8 h-8 text-zinc-600" />
                           </div>
                           <p className="text-zinc-500 font-bold uppercase tracking-widest text-xs">No college found with that name</p>
                        </div>
                      )}

                      {/* Add New Option */}
                      <button 
                        onClick={() => navigate(`/add`)}
                        className="w-full p-6 bg-primary/10 hover:bg-primary/20 transition-all flex items-center gap-4 border-t border-primary/10"
                      >
                        <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center">
                           <Plus className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                           <div className="font-black text-primary uppercase text-sm italic">Add "{searchQuery}"</div>
                           <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Expose this college to the world</div>
                        </div>
                      </button>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
          
          <div className="flex flex-wrap gap-3 mt-8 justify-center">
            {['Placement Scams', 'Mess Food 🤢', 'Hostel Life', 'Crowd Vibe', 'Attendance Rackets'].map((tag, i) => (
              <motion.span 
                key={tag} 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 + (i * 0.1) }}
                className="px-4 py-2 bg-zinc-900/80 border border-zinc-800 rounded-2xl text-[10px] md:text-xs font-black text-zinc-400 cursor-pointer hover:border-primary hover:text-primary hover:-translate-y-1 transition-all uppercase tracking-widest"
              >
                {tag}
              </motion.span>
            ))}
          </div>
        </div>
      </section>

      {/* Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Left Column: Trending */}
        <div className="lg:col-span-4 space-y-8">
          <div className="flex items-center justify-between">
             <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-500/10 rounded-xl">
                <Flame className="w-6 h-6 text-orange-500" />
              </div>
              <h2 className="text-2xl font-black font-display uppercase italic">Trending</h2>
            </div>
            <Link to="/colleges" className="text-xs font-bold text-zinc-500 hover:text-primary transition-colors">VIEW ALL</Link>
          </div>
          
          <div className="space-y-4">
            {(colleges.slice(0, 10)).map((college, i) => (
              <Link to={`/college/${college.slug}`} key={college.id} className="block group">
                <motion.div 
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-zinc-900/40 p-5 rounded-2xl border border-zinc-800/50 flex items-center justify-between group-hover:border-primary/40 group-hover:bg-zinc-900/60 transition-all cursor-pointer backdrop-blur-sm"
                >
                  <div className="flex items-center gap-5">
                    <span className="text-3xl font-black text-zinc-800 group-hover:text-primary/20 transition-colors tabular-nums">{String(i+1).padStart(2, '0')}</span>
                    <div>
                      <h3 className="font-black text-white group-hover:text-primary transition-colors">{college.name}</h3>
                      <p className="text-xs font-bold text-zinc-600 uppercase tracking-tighter">{college.location}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-black font-display text-2xl text-primary leading-none">
                      {college.reviewCount > 0 ? college.overallRating : 'NR'}
                    </div>
                    <div className="text-[9px] font-black text-zinc-700 uppercase tracking-[0.2em] mt-1">
                      {college.reviewCount > 0 ? 'SCORE' : 'NO DATA'}
                    </div>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>

          {/* Review Bounty Card */}
          <div className="bg-gradient-to-br from-primary/10 to-accent/10 p-8 rounded-3xl border border-primary/10 relative overflow-hidden group">
             <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
               <Zap className="w-20 h-20 text-primary" />
             </div>
             <h3 className="text-lg font-black text-primary mb-2 italic">REVIEW BOUNTY 🎯</h3>
             <p className="text-sm text-zinc-400 mb-6 font-medium">No one has exposed the reality of <span className="text-white font-bold">{colleges.length > 0 ? colleges[Math.floor(Math.random() * colleges.length)].name : 'your college'}</span> yet. Be the first!</p>
             <Link 
               to="/add" 
               className="block w-full py-4 bg-primary text-black text-center rounded-2xl font-black text-sm hover:scale-[1.02] transition-transform active:scale-95 shadow-lg shadow-primary/20"
             >
                CLAIM THE BOUNTY 💀
             </Link>
          </div>
        </div>

        {/* Right Column: Feed */}
        <div className="lg:col-span-8 space-y-8">
           <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-xl">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-2xl font-black font-display uppercase italic">Confessions Feed</h2>
            </div>
            <div className="flex gap-2 bg-zinc-950 p-1 rounded-xl border border-zinc-900">
               {[
                 { id: 'top', label: 'Top', icon: TrendingUp },
                 { id: 'new', label: 'New', icon: MessageSquare },
                 { id: 'savage', label: 'Savage', icon: Skull }
               ].map((tab) => (
                 <button 
                  key={tab.id}
                  onClick={() => setSortBy(tab.id as any)}
                  className={cn(
                    "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
                    sortBy === tab.id ? "bg-zinc-800 text-primary" : "text-zinc-600 hover:text-zinc-400"
                  )}
                 >
                   <tab.icon className="w-3.5 h-3.5" />
                   {tab.label}
                 </button>
               ))}
            </div>
          </div>

          <div className="space-y-8">
            {reviews.map((review) => (
              <MemeCard key={review.id} review={review} onShare={handleShare} />
            ))}
            
            {!loading && reviews.length === 0 && (
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-zinc-900/30 border-2 border-dashed border-zinc-800 rounded-[40px] p-16 text-center space-y-6"
              >
                <div className="w-24 h-24 bg-zinc-900 rounded-full flex items-center justify-center mx-auto border border-zinc-800">
                   <MessageSquare className="w-10 h-10 text-zinc-700" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-3xl font-black font-display uppercase italic">The Chaos is quiet... for now 🦗</h3>
                  <p className="text-zinc-500 max-w-sm mx-auto">None of these colleges have been exposed yet. Be the first to start the fire. 🔥</p>
                </div>
                <div className="pt-4">
                  <Link 
                    to="/add" 
                    className="inline-flex items-center gap-3 bg-white text-black px-10 py-5 rounded-3xl font-black text-xl hover:bg-primary transition-all shadow-xl hover:shadow-primary/20 group"
                  >
                    START THE CONFESSIONS 💀
                  </Link>
                </div>
              </motion.div>
            )}

            {loading && <div className="text-center py-12 text-zinc-500 font-bold uppercase tracking-widest animate-pulse">Scanning the chaos...</div>}
            
            {/* Load More Trigger (Simulation) */}
            {!loading && reviews.length > 0 && (
              <div className="py-12 text-center">
                <button className="px-8 py-3 bg-zinc-900 border border-zinc-800 rounded-2xl font-black text-zinc-500 hover:text-white hover:border-primary transition-all">
                  LOAD MORE CHAOS...
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <Toast 
        isVisible={toast.show}
        message={toast.msg}
        onClose={() => setToast({ show: false, msg: '' })}
      />
    </div>
  );
};
