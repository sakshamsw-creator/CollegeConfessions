import { 
  collection, 
  addDoc, 
  getDocs, 
  getDoc,
  query, 
  where, 
  orderBy, 
  limit, 
  doc, 
  updateDoc, 
  increment,
  serverTimestamp 
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Review, College } from '../types';

export const ReviewService = {
  async getAllReviews(sortBy: 'top' | 'new' | 'savage' = 'top', limitCount = 20) {
    let q;
    const baseCollection = collection(db, 'reviews');
    
    if (sortBy === 'new') {
      q = query(
        baseCollection, 
        where('status', '==', 'approved'),
        orderBy('createdAt', 'desc'), 
        limit(limitCount)
      );
    } else if (sortBy === 'savage') {
      // Savage is a mix of high reactions and votes
      // Ideally we'd have a 'savageScore' calculated field, 
      // for now let's sort by votes as proxy or just get them and sort in memory if small
      q = query(
        baseCollection,
        where('status', '==', 'approved'),
        orderBy('votes', 'desc'),
        limit(limitCount)
      );
    } else {
      // Default: Top (highest net score)
      q = query(
        baseCollection, 
        where('status', '==', 'approved'),
        orderBy('votes', 'desc'), 
        limit(limitCount)
      );
    }

    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => ({ id: d.id, ...(d.data() as any) } as Review));
  },

  async getReviewsByCollege(collegeId: string, sortBy: 'top' | 'new' = 'top') {
    const q = query(
      collection(db, 'reviews'),
      where('collegeId', '==', collegeId),
      where('status', '==', 'approved'),
      orderBy(sortBy === 'top' ? 'votes' : 'createdAt', 'desc')
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => ({ id: d.id, ...(d.data() as any) } as Review));
  },

  async createReview(reviewData: Partial<Review>) {
    if (!auth.currentUser) throw new Error('Not authenticated');

    // Check if college has any reviews to award "Founding Voice"
    const collegeRef = doc(db, 'colleges', reviewData.collegeId as string);
    const collegeSnap = await getDoc(collegeRef);
    const isFirstReview = !collegeSnap.exists() || (collegeSnap.data()?.reviewCount || 0) === 0;

    const newReview = {
      ...reviewData,
      userId: auth.currentUser.uid,
      status: 'approved', // Auto-approve for demo
      votes: 0,
      upvotes: 0,
      downvotes: 0,
      reactions: { skull: 0, fire: 0, laugh: 0 },
      isFoundingVoice: isFirstReview,
      createdAt: serverTimestamp()
    };

    const reviewRef = await addDoc(collection(db, 'reviews'), newReview);
    
    // Update college review count and ratings
    if (collegeSnap.exists()) {
      const data = collegeSnap.data();
      const oldCount = data.reviewCount || 0;
      const newCount = oldCount + 1;
      
      const updatePayload: any = {
        reviewCount: increment(1)
      };

      // Calculate new overall rating
      const oldRating = data.overallRating || 0;
      const newRating = reviewData.rating || 0;
      updatePayload.overallRating = parseFloat(((oldRating * oldCount + newRating) / newCount).toFixed(1));

      // Calculate new category ratings
      if (reviewData.categoryRatings) {
        const newCatRatings: any = {};
        Object.entries(reviewData.categoryRatings).forEach(([key, val]) => {
          const oldCatAvg = data.categoryRatings?.[key] || 0;
          newCatRatings[key] = parseFloat(((oldCatAvg * oldCount + (val as number)) / newCount).toFixed(1));
        });
        updatePayload.categoryRatings = newCatRatings;
      }

      await updateDoc(collegeRef, updatePayload);
    }

    return reviewRef;
  },

  async vote(reviewId: string, voteType: 'up' | 'down' | null, previousVote: 'up' | 'down' | null) {
    const docRef = doc(db, 'reviews', reviewId);
    
    let votesDelta = 0;
    let upvotesDelta = 0;
    let downvotesDelta = 0;

    // Remove previous vote impact
    if (previousVote === 'up') {
      votesDelta -= 1;
      upvotesDelta -= 1;
    } else if (previousVote === 'down') {
      votesDelta += 1;
      downvotesDelta -= 1;
    }

    // Add new vote impact
    if (voteType === 'up') {
      votesDelta += 1;
      upvotesDelta += 1;
    } else if (voteType === 'down') {
      votesDelta -= 1;
      downvotesDelta += 1;
    }

    await updateDoc(docRef, {
      votes: increment(votesDelta),
      upvotes: increment(upvotesDelta),
      downvotes: increment(downvotesDelta)
    });

    // Check for NEW MOD (the user with most UPVOTES)
    const reviewSnap = await getDoc(docRef);
    if (reviewSnap.exists()) {
      const collegeId = reviewSnap.data().collegeId;
      const reviewsQ = query(
        collection(db, 'reviews'),
        where('collegeId', '==', collegeId),
        where('status', '==', 'approved'),
        orderBy('upvotes', 'desc'),
        limit(1)
      );
      const topReviewSnapshot = await getDocs(reviewsQ);
      if (!topReviewSnapshot.empty) {
        const topReviewerId = topReviewSnapshot.docs[0].data().userId;
        const collegeRef = doc(db, 'colleges', collegeId);
        const collegeSnap = await getDoc(collegeRef);
        if (collegeSnap.exists()) {
          const currentModId = collegeSnap.data().currentModId;
          if (currentModId !== topReviewerId) {
             console.log("New MOD assigned for college:", collegeId, topReviewerId);
             await updateDoc(collegeRef, { currentModId: topReviewerId });
          }
        }
      }
    }
  },

  async react(reviewId: string, reactionType: 'skull' | 'fire' | 'laugh') {
    const docRef = doc(db, 'reviews', reviewId);
    await updateDoc(docRef, {
      [`reactions.${reactionType}`]: increment(1)
    });
  }
};

export const CollegeService = {
  async getAllColleges() {
    const snapshot = await getDocs(collection(db, 'colleges'));
    return snapshot.docs.map(d => ({ id: d.id, ...(d.data() as any) } as College));
  },

  async getCollegeBySlug(slug: string) {
    const q = query(
      collection(db, 'colleges'),
      where('slug', '==', slug)
    );
    const snapshot = await getDocs(q);
    if (snapshot.empty) return null;
    const doc = snapshot.docs[0];
    return { id: doc.id, ...doc.data() } as College;
  },

  async findByName(name: string) {
    const q = query(
      collection(db, 'colleges'),
      where('name', '==', name) // Firestore is case-sensitive, for scale we'd need a normalized field
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => ({ id: d.id, ...(d.data() as any) } as College))[0];
  },

  async createCollege(name: string, location: string = 'Unknown') {
    // Check for existing college by name first
    const existing = await this.findByName(name);
    if (existing) {
      throw new Error(`College "${name}" already exists in our records.`);
    }

    const slug = name.toLowerCase()
      .trim()
      .replace(/[^a-z0-9]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-+|-+$/g, '');

    const newCollege = {
      name: name.trim(),
      slug,
      location: location.trim() || 'Unknown',
      imageUrl: `https://picsum.photos/seed/${slug}/800/600`,
      overallRating: 0,
      reviewCount: 0,
      categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
    };
    
    try {
      const docRef = await addDoc(collection(db, 'colleges'), newCollege);
      return { id: docRef.id, ...newCollege } as College;
    } catch (error) {
      console.error("Critical error in createCollege:", error);
      throw error;
    }
  },

  async updateCollege(collegeId: string, data: Partial<College>) {
    const docRef = doc(db, 'colleges', collegeId);
    await updateDoc(docRef, data);
  }
};

export const PollService = {
  async getPollForCollege(collegeId: string, pollType: string = 'rechoice') {
    const q = query(
      collection(db, 'polls'),
      where('collegeId', '==', collegeId),
      where('type', '==', pollType)
    );
    const snapshot = await getDocs(q);
    if (snapshot.empty) return null;
    const doc = snapshot.docs[0];
    return { id: doc.id, ...doc.data() } as any;
  },

  async voteInPoll(pollId: string, optionId: string) {
    const pollRef = doc(db, 'polls', pollId);
    
    // We need to increment the specific option's votes
    // Since options is an array, we'll fetch then update or use a more scalable structure
    // For now, let's fetch, modify and save
    const snapshot = await getDoc(pollRef);
    if (!snapshot.exists()) return;
    
    const data = snapshot.data();
    const options = data.options.map((opt: any) => {
      if (opt.id === optionId) {
        return { ...opt, votes: (opt.votes || 0) + 1 };
      }
      return opt;
    });

    await updateDoc(pollRef, { options });
  },

  async createPoll(collegeId: string, question: string, options: { id: string, text: string }[], type: string = 'rechoice') {
    const newPoll = {
      collegeId,
      question,
      options: options.map(o => ({ ...o, votes: 0 })),
      type,
      createdAt: serverTimestamp()
    };
    return await addDoc(collection(db, 'polls'), newPoll);
  }
};

export const UserService = {
  async getUserProfile(uid: string) {
    const docRef = doc(db, 'users', uid);
    const snapshot = await getDoc(docRef);
    if (!snapshot.exists()) return null;
    return { id: snapshot.id, ...snapshot.data() } as any;
  }
};
