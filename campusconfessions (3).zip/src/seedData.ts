import { College, Review } from './types';

export const SEED_COLLEGES: College[] = [
  {
    id: 'iit-bombay', name: 'IIT Bombay', slug: 'iit-bombay', location: 'Mumbai, Maharashtra',
    imageUrl: 'https://picsum.photos/seed/iitb/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'bits-pilani', name: 'BITS Pilani', slug: 'bits-pilani', location: 'Pilani, Rajasthan',
    imageUrl: 'https://picsum.photos/seed/bits/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'vit-vellore', name: 'VIT Vellore', slug: 'vit-vellore', location: 'Vellore, Tamil Nadu',
    imageUrl: 'https://picsum.photos/seed/vit/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'iit-delhi', name: 'IIT Delhi', slug: 'iit-delhi', location: 'New Delhi',
    imageUrl: 'https://picsum.photos/seed/iitd/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'nit-trichy', name: 'NIT Trichy', slug: 'nit-trichy', location: 'Tiruchirappalli, Tamil Nadu',
    imageUrl: 'https://picsum.photos/seed/nitt/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'srm-kattankulathur', name: 'SRM Kattankulathur', slug: 'srm-kattankulathur', location: 'Chennai, Tamil Nadu',
    imageUrl: 'https://picsum.photos/seed/srm/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'mit-manipal', name: 'MIT Manipal', slug: 'mit-manipal', location: 'Manipal, Karnataka',
    imageUrl: 'https://picsum.photos/seed/manipal/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'dtu-delhi', name: 'DTU', slug: 'dtu-delhi', location: 'Delhi',
    imageUrl: 'https://picsum.photos/seed/dtu/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'christ-university', name: 'Christ University', slug: 'christ-university', location: 'Bangalore, Karnataka',
    imageUrl: 'https://picsum.photos/seed/christ/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'st-stephens', name: "St. Stephen's College", slug: 'st-stephens', location: 'New Delhi',
    imageUrl: 'https://picsum.photos/seed/stephens/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'jntu-hyderabad', name: 'JNTU Hyderabad', slug: 'jntu-hyderabad', location: 'Hyderabad, Telangana',
    imageUrl: 'https://picsum.photos/seed/jntu/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'thapar-university', name: 'Thapar University', slug: 'thapar-university', location: 'Patiala, Punjab',
    imageUrl: 'https://picsum.photos/seed/thapar/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'rvce-bangalore', name: 'RVCE Bangalore', slug: 'rvce-bangalore', location: 'Bangalore, Karnataka',
    imageUrl: 'https://picsum.photos/seed/rvce/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'nsut-delhi', name: 'NSUT Delhi', slug: 'nsut-delhi', location: 'New Delhi',
    imageUrl: 'https://picsum.photos/seed/nsut/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'srcc-delhi', name: 'SRCC', slug: 'srcc-delhi', location: 'New Delhi',
    imageUrl: 'https://picsum.photos/seed/srcc/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'iit-madras', name: 'IIT Madras', slug: 'iit-madras', location: 'Chennai, Tamil Nadu',
    imageUrl: 'https://picsum.photos/seed/iitm/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'nit-surathkal', name: 'NIT Surathkal', slug: 'nit-surathkal', location: 'Surathkal, Karnataka',
    imageUrl: 'https://picsum.photos/seed/nitsk/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'bits-goa', name: 'BITS Goa', slug: 'bits-goa', location: 'Zuarinagar, Goa',
    imageUrl: 'https://picsum.photos/seed/bitsg/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'lsr-delhi', name: 'LSR Delhi', slug: 'lsr-delhi', location: 'New Delhi',
    imageUrl: 'https://picsum.photos/seed/lsr/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'loyola-chennai', name: 'Loyola College', slug: 'loyola-chennai', location: 'Chennai, Tamil Nadu',
    imageUrl: 'https://picsum.photos/seed/loyola/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  },
  {
    id: 'vit-chennai', name: 'VIT Chennai', slug: 'vit-chennai', location: 'Chennai, Tamil Nadu',
    imageUrl: 'https://picsum.photos/seed/vitc/800/600', overallRating: 0, reviewCount: 0,
    categoryRatings: { teaching: 0, placement: 0, life: 0, hostel: 0, crowd: 0 }
  }
];

export const SEED_REVIEWS: Review[] = [
  {
    id: 'seed-1',
    collegeId: 'vit-vellore',
    userId: 'system-seed',
    headline: 'The Attendance Prison ⛓️',
    contentText: 'You pay for a degree but you actually pay for a parole officer called an HOD. 75% attendance is a myth, they want 100% of your soul. The placement numbers are inflated by mass recruiters who pay peanuts.',
    expectationVsReality: 'Expected high-tech campus. Got a high-security complex.',
    biggestScam: 'The proctor system. 💀',
    rating: 4.5,
    categoryRatings: { teaching: 5, placement: 7, life: 2, hostel: 3, crowd: 6 },
    tags: ['Attendance', 'Strict', 'PrisonVibes'],
    votes: 420,
    upvotes: 450,
    downvotes: 30,
    reactions: { skull: 88, fire: 45, laugh: 12 },
    status: 'approved',
    createdAt: new Date().toISOString(),
    isFoundingVoice: true
  },
  {
    id: 'seed-2',
    collegeId: 'iit-bombay',
    userId: 'system-seed-2',
    headline: 'Placement or Mental Health? Pick one. 💸',
    contentText: 'The legacy is real, but so is the burnout. Everyone here is a genius which means you will feel like a potato every single day. The packages are huge but so are the therapy bills.',
    expectationVsReality: 'Expected to be the next Sundar Pichai. Currently just trying to survive the next quiz.',
    bestThing: 'The brand name opens every door. 🚀',
    rating: 8.2,
    categoryRatings: { teaching: 8, placement: 10, life: 7, hostel: 5, crowd: 9 },
    tags: ['Stress', 'Elite', 'Burnout'],
    votes: 350,
    upvotes: 360,
    downvotes: 10,
    reactions: { skull: 12, fire: 89, laugh: 34 },
    status: 'approved',
    createdAt: new Date().toISOString(),
    isFoundingVoice: true
  },
  {
    id: 'seed-3',
    collegeId: 'bits-pilani',
    userId: 'system-seed-3',
    headline: 'Zero Attendance, Infinite Fees 💰',
    contentText: 'Best thing is no attendance policy. Worst thing is the fee hikes every semester. It feels like BITS is trying to fund a space colony with our tuition. The meritocracy is great though.',
    expectationVsReality: 'Expected free degree from a non-profit. Got a profit center.',
    biggestScam: 'The 10% annual fee hike. 💀',
    rating: 8.8,
    categoryRatings: { teaching: 9, placement: 9, life: 10, hostel: 7, crowd: 10 },
    tags: ['NoAttendance', 'Expensive', 'Merit'],
    votes: 280,
    upvotes: 290,
    downvotes: 10,
    reactions: { skull: 5, fire: 67, laugh: 150 },
    status: 'approved',
    createdAt: new Date().toISOString(),
    isFoundingVoice: true
  }
];
