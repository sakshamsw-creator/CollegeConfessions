export interface College {
  id: string;
  name: string;
  slug: string;
  location: string;
  imageUrl: string;
  overallRating: number;
  reviewCount: number;
  categoryRatings: {
    teaching: number;
    placement: number;
    life: number;
    hostel: number;
    crowd: number;
  };
  currentModId?: string;
}

export interface UserProfile {
  uid: string;
  anonymousName: string;
  photoURL?: string;
  createdAt: any;
}

export interface Review {
  id: string;
  collegeId: string;
  userId: string;
  headline: string;
  contentText: string;
  expectationVsReality: string;
  biggestScam?: string;
  bestThing?: string;
  rating: number;
  categoryRatings: {
    teaching: number;
    placement: number;
    life: number;
    hostel: number;
    crowd: number;
  };
  tags: string[];
  votes: number; // Net score
  upvotes: number;
  downvotes: number;
  reactions: {
    skull: number;
    fire: number;
    laugh: number;
  };
  status: 'pending' | 'approved' | 'flagged';
  createdAt: string;
  isFoundingVoice?: boolean;
}

export interface Poll {
  id: string;
  collegeId: string;
  question: string;
  options: {
    id: string;
    text: string;
    votes: number;
  }[];
}
